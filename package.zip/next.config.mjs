/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['cdn.pixabay.com','mdbcdn.b-cdn.net'],
    },
  };
  
  export default nextConfig;